# Gepe3D
 Gonkee's Epic Physics Engine 3D (Gepe3D)
 
 soft body and fluid game type of thing made in OpenCL
 
 This is just here so you can see the code
 
 Please don't do pull requests or issues i probably wont look at them
 
 [Click here to download ZIP file containing EXE](https://github.com/Gonkee/Gepe3D/releases/download/breh/Gepe3D_win-x64.zip)
 
 (or click the releases section on the right)
 
Keybinds:
 - W: move forward
 - S: move backward
 - A: move left
 - D: move right
 - Space: move up
 - Left Shift: move down
 - Escape: close program

References:

- [Matthias Müller et al - "Position Based Dynamics"](https://matthias-research.github.io/pages/publications/posBasedDyn.pdf)
- [Miles Macklin and Matthias Müller - "Position based fluids"](http://mmacklin.com/pbf_sig_preprint.pdf)
- [Miles Macklin et al - "Unified Particle Physics for Real-Time Applications"](https://mmacklin.com/uppfrta_preprint.pdf)
- [Simon Green - "Particle Simulation using CUDA"](http://developer.download.nvidia.com/assets/cuda/files/particles.pdf)
